interface IArea {
    area(): number;
}